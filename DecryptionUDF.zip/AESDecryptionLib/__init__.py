__all__ = ['TCCICipher.py_old']

__revision__ = "$Id$"