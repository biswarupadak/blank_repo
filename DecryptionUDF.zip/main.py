#!/usr/bin/python

from AESDecryptionLib.TCCIAESCipher import AESCipherText

cipher = AESCipherText('tfs-tcci-pii-data-encryption-key')
encrypted = cipher.encrypt('Secret Message ABC222222222222222222222222222222222')
decrypted = cipher.decrypt(encrypted)
print encrypted
print decrypted