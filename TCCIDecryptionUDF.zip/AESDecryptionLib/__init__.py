__all__ = ['TCCICipher']

__revision__ = "$Id$"