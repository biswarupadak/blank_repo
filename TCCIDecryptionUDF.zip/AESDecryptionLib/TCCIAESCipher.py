#!/usr/bin/python

import base64
import pyaes



# A 256 bit (32 byte) key
key = "This_key_for_demo_purposes_only!"

# For some modes of operation we need a random initialization vector
# of 16 bytes
iv = "InitializationVe"



class AESCipherText:

    def __init__(self, key):
        self.key = key
        self.aes = pyaes.AESModeOfOperationOFB(key, iv=iv)

    def encrypt(self, raw):
        ciphertext = base64.b64encode( self.aes.encrypt(raw))
        print 'Encrypted Text : '+ciphertext
        return ciphertext

    def decrypt(self, enc):
        aes = pyaes.AESModeOfOperationOFB(self.key, iv=iv)
        decrypted = aes.decrypt(base64.b64decode(enc))
        print 'Decrypted Text : '+decrypted
        return decrypted
