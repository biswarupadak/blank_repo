#!/usr/bin/python

from AESDecryptionLib.TCCIAESCipher import AESCipherText

cipher = AESCipherText('This_key_for_demo_purposes_only!')
encrypted = cipher.encrypt('Secret Message ABC222222222222222222222222222222222')
decrypted = cipher.decrypt('canacQqLH6pIQwi2t6nEQ0IXm7Lb3TqJazTPfZMB7MczqVFf6MiSuxcYsauDnozs9vut')
print encrypted
print decrypted