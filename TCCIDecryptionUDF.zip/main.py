#!/usr/bin/python

from AESDecryptionLib.Cipher import AESCipher

cipher = AESCipher('mysecretpassword')
encrypted = cipher.encrypt('Secret Message ABC222222222222222222222222222222222')
decrypted = cipher.decrypt('Z036eliF0w066D/QNHbrn9eU1/uiK2QiEYw6S2CMrEM=')
print encrypted
print decrypted