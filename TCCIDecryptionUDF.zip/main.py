#!/usr/bin/python

from AESDecryptionLib.TCCICipher import AESCipherText

cipher = AESCipherText('mysecretpassword')
encrypted = cipher.encrypt('Secret Message ABC222222222222222222222222222222222')
decrypted = cipher.decrypt(encrypted)
print encrypted
print decrypted